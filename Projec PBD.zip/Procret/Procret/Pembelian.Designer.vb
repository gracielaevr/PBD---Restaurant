﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Pembelian
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Pembelian))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.btn_pesan = New System.Windows.Forms.Button()
        Me.Tambahan = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.dt_nt = New System.Windows.Forms.DateTimePicker()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.dt_note = New System.Windows.Forms.TextBox()
        Me.tb_note = New System.Windows.Forms.TextBox()
        Me.gb_book = New System.Windows.Forms.GroupBox()
        Me.tb_dtl = New System.Windows.Forms.RichTextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.dt_a = New System.Windows.Forms.DateTimePicker()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.dt_b = New System.Windows.Forms.DateTimePicker()
        Me.btn_resetb = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.tb_kdb = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.gb_pel = New System.Windows.Forms.GroupBox()
        Me.btn_rst = New System.Windows.Forms.Button()
        Me.tb_tlp = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.tb_namapel = New System.Windows.Forms.TextBox()
        Me.tb_kdpel = New System.Windows.Forms.TextBox()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Tambahan.SuspendLayout()
        Me.gb_book.SuspendLayout()
        Me.gb_pel.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label3.Location = New System.Drawing.Point(348, 17)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 20)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "ini jam"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(136, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel2.Controls.Add(Me.PictureBox2)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Location = New System.Drawing.Point(200, 1)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(844, 49)
        Me.Panel2.TabIndex = 8
        '
        'PictureBox2
        '
        Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(780, 10)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(33, 27)
        Me.PictureBox2.TabIndex = 8
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.ErrorImage = CType(resources.GetObject("PictureBox1.ErrorImage"), System.Drawing.Image)
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(990, 5)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(28, 34)
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(136, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel6.Location = New System.Drawing.Point(18, 189)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(160, 1)
        Me.Panel6.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(13, 158)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(94, 20)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Pemesanan"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(136, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel3.Location = New System.Drawing.Point(18, 295)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(160, 1)
        Me.Panel3.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(13, 264)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 20)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Daftar User"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(136, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel4.Location = New System.Drawing.Point(18, 239)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(160, 1)
        Me.Panel4.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 208)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(98, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Daftar Menu"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Panel6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Panel4)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(1, 1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(200, 564)
        Me.Panel1.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(14, 66)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(89, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Nama Pelanggan"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.White
        Me.Panel5.Controls.Add(Me.btn_pesan)
        Me.Panel5.Controls.Add(Me.Tambahan)
        Me.Panel5.Controls.Add(Me.gb_book)
        Me.Panel5.Controls.Add(Me.gb_pel)
        Me.Panel5.Location = New System.Drawing.Point(212, 65)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(801, 290)
        Me.Panel5.TabIndex = 12
        '
        'btn_pesan
        '
        Me.btn_pesan.Font = New System.Drawing.Font("Century Gothic", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_pesan.Location = New System.Drawing.Point(562, 213)
        Me.btn_pesan.Name = "btn_pesan"
        Me.btn_pesan.Size = New System.Drawing.Size(204, 61)
        Me.btn_pesan.TabIndex = 15
        Me.btn_pesan.Text = "Pesan Menu"
        Me.btn_pesan.UseVisualStyleBackColor = True
        '
        'Tambahan
        '
        Me.Tambahan.Controls.Add(Me.Button1)
        Me.Tambahan.Controls.Add(Me.dt_nt)
        Me.Tambahan.Controls.Add(Me.Label14)
        Me.Tambahan.Controls.Add(Me.Label4)
        Me.Tambahan.Controls.Add(Me.Label10)
        Me.Tambahan.Controls.Add(Me.dt_note)
        Me.Tambahan.Controls.Add(Me.tb_note)
        Me.Tambahan.Location = New System.Drawing.Point(534, 13)
        Me.Tambahan.Name = "Tambahan"
        Me.Tambahan.Size = New System.Drawing.Size(252, 188)
        Me.Tambahan.TabIndex = 16
        Me.Tambahan.TabStop = False
        Me.Tambahan.Text = "Catatan Pesanan"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(17, 146)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "Reset"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'dt_nt
        '
        Me.dt_nt.Location = New System.Drawing.Point(17, 120)
        Me.dt_nt.Name = "dt_nt"
        Me.dt_nt.Size = New System.Drawing.Size(200, 20)
        Me.dt_nt.TabIndex = 20
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(14, 104)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(46, 13)
        Me.Label14.TabIndex = 19
        Me.Label14.Text = "Tanggal"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(14, 25)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(72, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Kode Catatan"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(14, 64)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(74, 13)
        Me.Label10.TabIndex = 4
        Me.Label10.Text = "Detail Catatan"
        '
        'dt_note
        '
        Me.dt_note.Location = New System.Drawing.Point(17, 80)
        Me.dt_note.Name = "dt_note"
        Me.dt_note.Size = New System.Drawing.Size(230, 20)
        Me.dt_note.TabIndex = 5
        '
        'tb_note
        '
        Me.tb_note.Location = New System.Drawing.Point(17, 41)
        Me.tb_note.Name = "tb_note"
        Me.tb_note.Size = New System.Drawing.Size(106, 20)
        Me.tb_note.TabIndex = 6
        '
        'gb_book
        '
        Me.gb_book.Controls.Add(Me.tb_dtl)
        Me.gb_book.Controls.Add(Me.Label12)
        Me.gb_book.Controls.Add(Me.dt_a)
        Me.gb_book.Controls.Add(Me.Label11)
        Me.gb_book.Controls.Add(Me.dt_b)
        Me.gb_book.Controls.Add(Me.btn_resetb)
        Me.gb_book.Controls.Add(Me.Label8)
        Me.gb_book.Controls.Add(Me.tb_kdb)
        Me.gb_book.Controls.Add(Me.Label9)
        Me.gb_book.Location = New System.Drawing.Point(17, 13)
        Me.gb_book.Name = "gb_book"
        Me.gb_book.Size = New System.Drawing.Size(253, 261)
        Me.gb_book.TabIndex = 15
        Me.gb_book.TabStop = False
        Me.gb_book.Text = "Data Booking"
        '
        'tb_dtl
        '
        Me.tb_dtl.Location = New System.Drawing.Point(22, 159)
        Me.tb_dtl.Name = "tb_dtl"
        Me.tb_dtl.Size = New System.Drawing.Size(200, 59)
        Me.tb_dtl.TabIndex = 20
        Me.tb_dtl.Text = ""
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(19, 143)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(57, 13)
        Me.Label12.TabIndex = 19
        Me.Label12.Text = "Detail Lain"
        '
        'dt_a
        '
        Me.dt_a.Location = New System.Drawing.Point(22, 120)
        Me.dt_a.Name = "dt_a"
        Me.dt_a.Size = New System.Drawing.Size(200, 20)
        Me.dt_a.TabIndex = 18
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(19, 104)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(77, 13)
        Me.Label11.TabIndex = 17
        Me.Label11.Text = "Tanggal Acara"
        '
        'dt_b
        '
        Me.dt_b.Location = New System.Drawing.Point(22, 81)
        Me.dt_b.Name = "dt_b"
        Me.dt_b.Size = New System.Drawing.Size(200, 20)
        Me.dt_b.TabIndex = 16
        '
        'btn_resetb
        '
        Me.btn_resetb.Location = New System.Drawing.Point(22, 224)
        Me.btn_resetb.Name = "btn_resetb"
        Me.btn_resetb.Size = New System.Drawing.Size(75, 23)
        Me.btn_resetb.TabIndex = 15
        Me.btn_resetb.Text = "Reset"
        Me.btn_resetb.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(19, 26)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(74, 13)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "Kode Booking" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'tb_kdb
        '
        Me.tb_kdb.Location = New System.Drawing.Point(22, 42)
        Me.tb_kdb.Name = "tb_kdb"
        Me.tb_kdb.Size = New System.Drawing.Size(106, 20)
        Me.tb_kdb.TabIndex = 12
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(19, 65)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(88, 13)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "Tanggal Booking"
        '
        'gb_pel
        '
        Me.gb_pel.Controls.Add(Me.btn_rst)
        Me.gb_pel.Controls.Add(Me.tb_tlp)
        Me.gb_pel.Controls.Add(Me.Label13)
        Me.gb_pel.Controls.Add(Me.Label7)
        Me.gb_pel.Controls.Add(Me.Label6)
        Me.gb_pel.Controls.Add(Me.tb_namapel)
        Me.gb_pel.Controls.Add(Me.tb_kdpel)
        Me.gb_pel.Location = New System.Drawing.Point(276, 13)
        Me.gb_pel.Name = "gb_pel"
        Me.gb_pel.Size = New System.Drawing.Size(252, 188)
        Me.gb_pel.TabIndex = 12
        Me.gb_pel.TabStop = False
        Me.gb_pel.Text = "Data Pelanggan"
        '
        'btn_rst
        '
        Me.btn_rst.Location = New System.Drawing.Point(17, 149)
        Me.btn_rst.Name = "btn_rst"
        Me.btn_rst.Size = New System.Drawing.Size(75, 23)
        Me.btn_rst.TabIndex = 5
        Me.btn_rst.Text = "Reset"
        Me.btn_rst.UseVisualStyleBackColor = True
        '
        'tb_tlp
        '
        Me.tb_tlp.Location = New System.Drawing.Point(17, 123)
        Me.tb_tlp.Name = "tb_tlp"
        Me.tb_tlp.Size = New System.Drawing.Size(213, 20)
        Me.tb_tlp.TabIndex = 9
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(14, 107)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(80, 13)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "Nomor Telepon"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(14, 27)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(86, 13)
        Me.Label7.TabIndex = 3
        Me.Label7.Text = "Kode Pelanggan"
        '
        'tb_namapel
        '
        Me.tb_namapel.Location = New System.Drawing.Point(17, 82)
        Me.tb_namapel.Name = "tb_namapel"
        Me.tb_namapel.Size = New System.Drawing.Size(213, 20)
        Me.tb_namapel.TabIndex = 1
        '
        'tb_kdpel
        '
        Me.tb_kdpel.Location = New System.Drawing.Point(17, 43)
        Me.tb_kdpel.Name = "tb_kdpel"
        Me.tb_kdpel.Size = New System.Drawing.Size(106, 20)
        Me.tb_kdpel.TabIndex = 2
        '
        'Pembelian
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(1028, 407)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Pembelian"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "1"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Tambahan.ResumeLayout(False)
        Me.Tambahan.PerformLayout()
        Me.gb_book.ResumeLayout(False)
        Me.gb_book.PerformLayout()
        Me.gb_pel.ResumeLayout(False)
        Me.gb_pel.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents tb_kdpel As TextBox
    Friend WithEvents tb_namapel As TextBox
    Friend WithEvents btn_rst As Button
    Friend WithEvents btn_pesan As Button
    Friend WithEvents gb_pel As GroupBox
    Friend WithEvents tb_tlp As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents gb_book As GroupBox
    Friend WithEvents tb_dtl As RichTextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents dt_a As DateTimePicker
    Friend WithEvents Label11 As Label
    Friend WithEvents dt_b As DateTimePicker
    Friend WithEvents btn_resetb As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents tb_kdb As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Tambahan As GroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents dt_note As TextBox
    Friend WithEvents tb_note As TextBox
    Friend WithEvents dt_nt As DateTimePicker
    Friend WithEvents Label14 As Label
    Friend WithEvents Button1 As Button
End Class
